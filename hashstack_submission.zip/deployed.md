## Deployed details

```
Diamond deployed: 0xAe301bd4828523a457d0485587cB0a42C9eDA912
Deploying facets
A deployed to: 0x98E8c52B6a5C7477F3f0C9D785EE1bE3C1787A9F
0x993a04b7: getter()
0x3e89340f: lockStatus()
0xd423740b: setter(uint256)
******************
B deployed to: 0x44A65106203fECd95712A5C6D04aB8b4DC104E81
0x70480275: addAdmin(address)
0x9a202d47: removeAdmin()
0x83b8a5ae: renounceAdminRole()
0xd8b8eefb: returnAdminA()
0xada8f919: transferAdminRole(address)
******************
Diamond cut
```

```
AUpgraded deployed to: 0xd29D23Dd8138B167Bf15C139CEf316C7e326dcb6
```
